<?php
$root = $_ENV['DOCUMENT_ROOT'] . '/';
if ($_ENV['DOCUMENT_ROOT']) {
    $root = $_ENV['DOCUMENT_ROOT'] . '/';
} elseif ($_SERVER['DOCUMENT_ROOT']) {
    $root = $_SERVER['DOCUMENT_ROOT'] . '/';
} else {
    $root = getenv("DOCUMENT_ROOT") . '/';
}
define('ROOT', $root);

$sk = new skclass();
$tpl = new template();
$enc = new AzDGCrypt("akr");

if ($_ENV["SCRIPT_NAME"]) {
    $skinscript = $_ENV["SCRIPT_NAME"];
} elseif ($_SERVER["REQUEST_URI"]) {
    $skinscript = $_SERVER["REQUEST_URI"];
} else {
    $skinscript = getenv("SCRIPT_NAME");
}

if (!strstr($skinscript, "CMD_SKINS") && !strstr($skinscript, "HTM_INDEX_RESELLER") && $skinscript != "/HTM_DEBUG" && !strstr($skinscript, "HTM_CAPRI") && $skinscript != "/") {
    $licArr = readLicense();
    if (!$licArr || !$licArr['lastcheck'] || $licArr['lastcheck'] < (mktime - (86400 * 7)) || $licArr['status'] = 'active') {
        $key = $licArr['licenseKey'];
        $path = getpath();
        $localKeyPath = $path['path'] . "key.php";
        $lic_status = checkLicence($key);
		$lic_status['status'] = "active";
        if ($lic_status['status'] != "active") {
            $urlStatus = $lic_status['status'] . "|||" . $lic_status['message'] . "|||" . $lic_status['adminmsg'];
            $urlStatus = urlencode(base64_encode($urlStatus));
            echo '<script language="JavaScript" type="text/javascript">window.location=\'/HTM_CAPRI?status=' . $urlStatus . '\';</script>';
            echo '<META HTTP-EQUIV="refresh" CONTENT="0; url=/HTM_CAPRI?status=' . $urlStatus . '">';
        }
    }
}

class template {

    function pagetit($pagetit, $tree) {
        global $sk;
        $invalidMsg = '<div style="padding: 20px 10px; border: 4px dotted #f00;color:#f00;background-color:#ffefec;font-weight:bold;font-size:16px;text-align:center;margin-bottom:15px;">This skin has an invalid license<br><span style="font-size: 12px;">You can get a license at <a href="http://www.outserices.net/">http://www.outserices.net/</a></span></div>';
        echo '<div class="pageTit"><span>' . $pagetit . '</span>' . $tree . '</div>';
    }

}

function getpath() {
    global $root;
    $skinpath = $root;
    if (preg_match("/\/home\/(.+)\/skins\/(.+)/", $skinpath)) {
        $return['owner'] = "reseller";
        $return['path'] = $skinpath . "/inc/";
    } elseif (preg_match("/\/usr\/local\/directadmin\/data\/skins\/(.+)/", $skinpath)) {
        $return['owner'] = "admin";
        if (file_exists("/usr/local/directadmin/data/skin_data/capri")) {
            $return['path'] = "/usr/local/directadmin/data/skin_data/capri/";
        } else {
            $return['path'] = $skinpath . "/inc/";
        }
    } else {
        if (file_exists("/usr/local/directadmin/data/skin_data/capri")) {
            $return['owner'] = "admin";
            $return['path'] = "/usr/local/directadmin/data/skin_data/capri/";
            return $return;
        } else {
            return false;
        }
    }
    return $return;
}

function openfile($file) {
    if (file_exists($file)) {
        if ($data = @file_get_contents($file)) {
            return $data;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function whitefile($str, $file) {
    if ($al = @fopen($file, "w")) {
        if (@is_writable($file)) {
            @fwrite($al, $str);
            return true;
        } else {
            return false;
        }
        @fclose($al);
    } else {
        return false;
    }
}

function saveLicense($licArr) {
    global $enc;
    $path = getpath();
    whitefile($enc->encrypt(base64_encode(@serialize($licArr))), $path['path'] . "data");
    whitefile($licArr['licenseKey'], $path['path'] . "license");
    @chmod($path['path'] . "data", 0777);
    @chmod($path['path'] . "license", 0777);
}

function readLicense() {
    global $enc;
    $path = getpath();
    return @unserialize(@base64_decode($enc->decrypt(openfile($path['path'] . "data"))));
}

function saveKey($key) {
    $licArr = readLicense();
    $licArr['licenseKey'] = $key;
    saveLicense($licArr);
}

function getKey() {
    $licArr = readLicense();
    $path = getpath();
    $key = openfile($path['path'] . "license");
    if ($licArr['licenseKey'])
        return $licArr['licenseKey'];
    return $key;
}

class skclass {

    function api_get($cmd, $post=false) {
        if (is_array($post)) {
            $is_post = true;
            $str = '';
            foreach ($post as $var => $value) {
                if (strlen($str) > 0)
                    $str .= '&';
                $str .= $var . '=' . urlencode($value);
            }
            $post = $str;
        } else {
            $is_post = false;
        }
        $headers = array();
        $headers['Host'] = '127.0.0.1:' . $_ENV['SERVER_PORT'];
        $headers['Cookie'] = 'session=' . $_ENV['SESSION_ID'] . '; key=' . $_ENV['SESSION_KEY'];
        if ($is_post) {
            $headers['Content-type'] = 'application/x-www-form-urlencoded';
            $headers['Content-length'] = strlen($post);
        }
        $send = ($is_post ? 'POST ' : 'GET ') . $cmd . " HTTP/1.1\r\n";
        foreach ($headers as $var => $value)
            $send .= $var . ': ' . $value . "\r\n";
        $send .= "\r\n";
        if ($is_post && strlen($post) > 0)
            $send .= $post . "\r\n\r\n";
        if ($_ENV["SSL"] == 1) {
            $sIP = 'ssl://127.0.0.1';
        } else {
            $sIP = '127.0.0.1';
        }
        $res = @fsockopen($sIP, $_SERVER['SERVER_PORT'], &$sock_errno, &$sock_errstr, 2);
        if ($sock_errno || $sock_errstr)
            return false;
        fputs($res, $send, strlen($send));
        $result = '';
        while (!feof($res))
            $result .= fgets($res, 32768);
        @fclose($res);
        $data = explode("\r\n\r\n", $result, 2);
        return $data[1];
    }

    function iconmenu($title, $items) {
        $output = '';
        for ($i = 0; $i < count($items); $i++) {
            if ($items[$i]['plugin']) {
                $itemimg = "/IMG_IC_PLUGIN";
                $plugintxt = $items[$i]['plugin'];
                if (strstr($plugintxt, "stat"))
                    $itemimg = "/IMG_IC_STATS";
                if (strstr($plugintxt, "Stat"))
                    $itemimg = "/IMG_IC_STATS";
                if (strstr($plugintxt, "awstats"))
                    $itemimg = "/IMG_IC_AWSTATS";
                if (strstr($plugintxt, "Awstats"))
                    $itemimg = "/IMG_IC_AWSTATS";
                if (strstr($plugintxt, "AwStats"))
                    $itemimg = "/IMG_IC_AWSTATS";
                if (strstr($plugintxt, "smtp"))
                    $itemimg = "/IMG_IC_STATS";
                if (strstr($plugintxt, "Ruby"))
                    $itemimg = "/IMG_IC_RUBY";
                if (strstr($plugintxt, "ruby"))
                    $itemimg = "/IMG_IC_RUBY";
                if (strstr($plugintxt, "rails"))
                    $itemimg = "/IMG_IC_RUBY";
                if (strstr($plugintxt, "Rails"))
                    $itemimg = "/IMG_IC_RUBY";
                if (strstr($plugintxt, "SMTP"))
                    $itemimg = "/IMG_IC_SMTP_CONTROL";
                if (strstr($plugintxt, "smtp"))
                    $itemimg = "/IMG_IC_SMTP_CONTROL";
                if (strstr($plugintxt, "Billing"))
                    $itemimg = "/IMG_IC_BILLING";
                if (strstr($plugintxt, "billing"))
                    $itemimg = "/IMG_IC_BILLING";
                if (strstr($plugintxt, "bill"))
                    $itemimg = "/IMG_IC_BILLING";
                if (strstr($plugintxt, "payment"))
                    $itemimg = "/IMG_IC_BILLING";
                if (strstr($plugintxt, "hotlink"))
                    $itemimg = "/IMG_IC_HOTLINK";
                if (strstr($plugintxt, "iTron"))
                    $itemimg = "/IMG_IC_ITRON";
                if (strstr($plugintxt, "installatron"))
                    $itemimg = "/IMG_IC_ITRON";
                if (strstr($plugintxt, "tomcat"))
                    $itemimg = "/IMG_IC_TOMCAT";
                if (strstr($plugintxt, "Tomcat"))
                    $itemimg = "/IMG_IC_TOMCAT";
                if (strstr(strtolower($plugintxt), "pear"))
                    $itemimg = "/IMG_IC_PEAR";
                if (strstr(strtolower($plugintxt), "pgsql"))
                    $itemimg = "/IMG_IC_PGSQL";
                if (strstr($plugintxt, "PostgreSQL"))
                    $itemimg = "/IMG_IC_PGSQL";
                if (strstr($plugintxt, "Postgre"))
                    $itemimg = "/IMG_IC_PGSQL";
                if (strstr(strtolower($plugintxt), "postgre"))
                    $itemimg = "/IMG_IC_PGSQL";
                if (strstr(strtolower($plugintxt), "softaculous"))
                    $itemimg = "/IMG_IC_SOFTAC";
                if (strstr(strtolower($plugintxt), "phpvs"))
                    $itemimg = "/IMG_IC_PHPVS";
                if (strstr(strtolower($plugintxt), "php version selector"))
                    $itemimg = "/IMG_IC_PHPVS";
                $pluglink = preg_replace("/<a(.*?)href=\"(.*?)\"(.*?)>(.*?)<\/a>/", "<a href=\"\\2\"><img src=\"$itemimg\"><br>\\4</a>", $items[$i]['plugin']);
                $output .= $pluglink;
            } else {
                $output .= '<a href="' . $items[$i]['link'] . '"';
                if ($items[$i]['js'])
                    $output .= ' onClick="' . $items[$i]['js'] . '"';
                $output .= '><img src="' . $items[$i]['img'] . '"><br>' . $items[$i]['txt'] . '</a>' . "\n";
            }
        }
        $start_menu = '<fieldset class="buttons-box"><legend>' . $title . '</legend>' . "\n";
        $end_menu = '</fieldset>' . "\n";
        echo $start_menu . $output . $end_menu;
    }

    function submenu($title, $items, $footer=false) {
        $output = '<table border="0" cellspacing="0" cellpadding="0" align="center"><tr>';
        $div = 1;
        for ($i = 0; $i < count($items); $i++) {
            $output .= '<td width="20%" align="center"><a href="' . $items[$i]['link'] . '" class="subitem" ' . $items[$i]['js'] . '><img src="' . $items[$i]['img'] . '" width="32" height="32" border="0"><br>' . $items[$i]['txt'] . '</a></td>';
            if ($div == 5) {
                $output .= '</tr><tr>';
                $div = 0;
            }
            $div++;
        }
        $output .= '</tr></table>';
        $start_menu = '<table width="100%" border="0" cellspacing="0" cellpadding="0" class=list><tr><td class=listtitle height="22" style="padding-left:3px;"><b>' . $title . '</b></td></tr><tr><td class=list>';
        $end_menu = '</td></tr>';
        if ($footer)
            $end_menu .= '<tr><td class="listend">' . $footer . '</td></tr>';
        $end_menu .= '</table>';
        echo $start_menu . $output . $end_menu;
    }

    function uptime($color=false) {
        $loads = urldecode($this->api_get("/CMD_API_LOAD_AVERAGE"));
        parse_str($loads);
        settype($one, "float");
        settype($five, "float");
        settype($fifteen, "float");
        if ($color) {
            if ($one >= 5)
                $one = "<span style='color:red;'><b>" . number_format($load1, 2, '.', '') . "</b></span>";
            if ($five >= 5)
                $five = "<span style='color:red;'><b>" . number_format($load5, 2, '.', '') . "</b></span>";
            if ($fifteen >= 5)
                $fifteen = "<span style='color:red;'><b>" . number_format($load15, 2, '.', '') . "</b></span>";
        }
        $load = $one . ", " . $five . ", " . $fifteen;
        return $load;
    }

    function getServices() {
        $str = $this->api_get('/CMD_API_SHOW_SERVICES', $post = false);
        if (strpos($str, "httpd") === false) {
            return false;
        }
        parse_str(urldecode($str), $servArr);
        return $servArr;
    }

    function getLogo($creator, $username) {
        $logo = '/IMG_SKIN_HEADER';
        $arrPath = getpath();
        if (file_exists($arrPath['path'] . "logos/" . $creator)) {
            $logo = '/IMG_RESLOGO_' . $creator;
        }
        if (file_exists($arrPath['path'] . "logos/" . $username)) {
            $logo = '/IMG_RESLOGO_' . $username;
        }
        return $logo;
    }

}

class AzDGCrypt {

    var $k;

    function AzDGCrypt($m) {
        $this->k = $m;
    }

    function ed($t) {
        $r = md5($this->k);
        $c = 0;
        $v = "";
        for ($i = 0; $i < strlen($t); $i++) {
            if ($c == strlen($r))
                $c = 0;$v.= substr($t, $i, 1) ^ substr($r, $c, 1);
            $c++;
        }
        return $v;
    }

    function encrypt($t) {
        srand((double) microtime() * 1000000);
        $r = md5(rand(0, 32000));
        $c = 0;
        $v = "";
        for ($i = 0; $i < strlen($t); $i++) {
            if ($c == strlen($r))
                $c = 0;$v.= substr($r, $c, 1) . (substr($t, $i, 1) ^ substr($r, $c, 1));
            $c++;
        }
        return base64_encode($this->ed($v));
    }

    function decrypt($t) {
        $t = $this->ed(base64_decode($t));
        $v = "";
        for ($i = 0; $i < strlen($t); $i++) {
            $md5 = substr($t, $i, 1);
            $i++;
            $v.= ( substr($t, $i, 1) ^ $md5);
        }
        return $v;
    }

}

function getLanguages($root) {
    $langdir = $root . "lang/";
    $languages = array();
    if ($handle = opendir($langdir)) {
        while (false !== ($file = readdir($handle))) {
            if ($file != "." && $file != ".." && is_dir($langdir . $file)) {
                $languages[] = $file;
            }
        }
        closedir($handle);
    }
    return $languages;
}

function getDomainsList() {
    global $sk;
    $ret = array();
    $r = $sk->api_get("/CMD_API_DOMAIN_OWNERS");
    $domainsOwn = @urldecode($r);
    @parse_str($domainsOwn, $domains);
    if (is_array($domains) && count($domains) > 0) {
        foreach ($domains as $domain => $ouwner) {
            $ret[str_replace('_', '.', $domain)] = $ouwner;
        }
    }
    return $ret;
}

function checkLicence($license, $localKey='') {
    $returned['status'] = "active";
    return $returned;
}

function make_token() {
    return md5('fde6c53b6ffd106d7aba038a349b5575' . time());
}

function get_key() {
    global $localKeyPath;
    $data = @file($localKeyPath);
    if (!$data) {
        return false;
    }
    $buffer = false;
    foreach ($data as $line) {
        $buffer.=$line;
    }
    if (!$buffer) {
        return false;
    }
    $buffer = @str_replace("<?PHP", "", $buffer);
    $buffer = @str_replace("?>", "", $buffer);
    $buffer = @str_replace("/*--", "", $buffer);
    $buffer = @str_replace("--*/", "", $buffer);
    return @str_replace("\n", "", $buffer);
}

function parse_local_key() {
    global $localKeyPath;
    if (!@file_exists($localKeyPath)) {
        return false;
    }
    $raw_data = @base64_decode(get_key());
    $raw_array = @explode("|", $raw_data);
    if (@is_array($raw_array) && @count($raw_array) < 8) {
        return false;
    }
    return $raw_array;
}

function validate_local_key($array) {
    $raw_array = parse_local_key();
    if (!@is_array($raw_array) || $raw_array === false)
        return "<verify status='invalid_key' message='Please contact support for a new license key.' />";
    if ($raw_array[9] && @strcmp(@md5("fde6c53b6ffd106d7aba038a349b5575" . $raw_array[9]), $raw_array[10]) != 0)
        return "<verify status='invalid_key' message='Please contact support for a new license key.' />";
    if (@strcmp(@md5("fde6c53b6ffd106d7aba038a349b5575" . $raw_array[1]), $raw_array[2]) != 0)
        return "<verify status='invalid_key' message='Please contact support for a new license key.' " . $raw_array[9] . " />";
    if ($raw_array[1] < time() && $raw_array[1] != "never")
        return "<verify status='invalid_key' message='Please contact support for a new license key.' " . $raw_array[9] . " />";
    return "<verify status='active' message='The license key is valid.' " . $raw_array[9] . " />";
}

function phpaudit_exec_socket($http_host, $http_dir, $http_file, $querystring) {
    $fp = @fsockopen($http_host, 80, $errno, $errstr, 10);
    if (!$fp) {
        return false;
    } else {
        $header = "POST " . ($http_dir . $http_file) . " HTTP/1.0\r\n";
        $header.="Host: " . $http_host . "\r\n";
        $header.="Content-type: application/x-www-form-urlencoded\r\n";
        $header.="User-Agent: PHPAudit v2 (http://www.phpaudit.com)\r\n";
        $header.="Content-length: " . @strlen($querystring) . "\r\n";
        $header.="Connection: close\r\n\r\n";
        $header.=$querystring;
        $data = false;
        if (@function_exists('stream_set_timeout')) {
            stream_set_timeout($fp, 20);
        }
        @fputs($fp, $header);
        if (@function_exists('socket_get_status')) {
            $status = @socket_get_status($fp);
        } else {
            $status = true;
        }
        while (!@feof($fp) && $status) {
            $data.= @ fgets($fp, 1024);
            if (@function_exists('socket_get_status')) {
                $status = @socket_get_status($fp);
            } else {
                if (@feof($fp) == true) {
                    $status = false;
                } else {
                    $status = true;
                }
            }
        }
        @fclose($fp);
        if (!strpos($data, '200')) {
            return false;
        }
        if (!$data) {
            return false;
        }
        $data = @explode("\r\n\r\n", $data, 2);
        if (!$data[1]) {
            return false;
        }
        if (@strpos($data[1], "verify") === false) {
            return false;
        }
        return $data[1];
    }
}

function server_addr() {
    return ($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : $_SERVER['LOCAL_ADDR'];
}

function getLocalKey($license) {
    global $licapi;
    include realpath(dirname(__FILE__)) . "/license.php";
    $licapi = new IXR_Client('http://localhost/admin/rpc.php');
    $data = array();
    $data['api_key'] = '2425f27c6bf1f8821c3283e3b3037085';
    $data['license_key'] = $license;
    $licapi->query('license.get_local_key', $data);
    $returned = $licapi->getResponse();
    if ($returned != '' && $returned['faultCode'] != -1 && $returned['faultCode'] != -2 && $returned['faultCode'] != -3) {
        return $returned;
    } else {
        return false;
    }
}
?>