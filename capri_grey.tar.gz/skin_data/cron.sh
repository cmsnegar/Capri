#!/bin/sh

PHPBIN="/usr/local/bin/php"
SKINDIRNAME="capri"
SOURCEPATH="http://www.outservices.net/soft"
DATADIR="/usr/local/directadmin/data/skin_data"
PLUGINPATH="/usr/local/directadmin/data/skin_data/$SKINDIRNAME"
SKINPATH="/usr/local/directadmin/data/skins/`cat $PLUGINPATH/name`"

doMessage()
{
  if [ -f "$PLUGINPATH/results" ]; then
    echo "$MESSAGE" >> $PLUGINPATH/results
  else
    echo "$MESSAGE" > $PLUGINPATH/results
  fi
  chmod 777 $PLUGINPATH/results
  chown diradmin:diradmin $PLUGINPATH/results
  exit 0;
  exit;
}

if [ -f "/usr/bin/php" ] && [ ! -f "/usr/local/bin/php" ]; then
  PHPBIN="/usr/bin/php"
fi

if [ -f "$PLUGINPATH/allowcustomlogo" ]; then

  if [ -f "$PLUGINPATH/_newlogo" ] && [ -f "$PLUGINPATH/_logodata" ]; then
    RESELLER="`cat $PLUGINPATH/_logodata`"
    IMGNAME="$RESELLER.gif"
    
    if [ ! -d "$SKINPATH/images/custom" ]; then
      mkdir $SKINPATH/images/custom
      chown diradmin:diradmin $SKINPATH/images/custom
    fi
    
    if [ -f "$SKINPATH/images/custom/$IMGNAME" ]; then
      rm -f $SKINPATH/images/custom/$IMGNAME
    fi
    
    mv $PLUGINPATH/_newlogo $SKINPATH/images/custom/$IMGNAME
    chmod 666 $SKINPATH/images/custom/$IMGNAME
    chown diradmin:diradmin $SKINPATH/images/custom/$IMGNAME
    
    if [ ! -d "$PLUGINPATH/logos" ]; then
      mkdir $PLUGINPATH/logos
      chmod 755 $PLUGINPATH/logos
    fi
    
    if [ -f "$SKINPATH/images/custom/$IMGNAME" ]; then
      cp $SKINPATH/images/custom/$IMGNAME $PLUGINPATH/logos/$RESELLER
      chmod 666 $PLUGINPATH/logos/$RESELLER
    fi
    
    RESELLERS=`cat /usr/local/directadmin/data/admin/reseller.list`
    echo -n "" > $SKINPATH/files_custom.conf
    for LINE in $RESELLERS; do
    {
      echo "IMG_RESLOGO_$LINE=images/custom/$LINE.gif" >> $SKINPATH/files_custom.conf
    }
    done;
    
    rm -f $PLUGINPATH/_logodata
  fi
  
else
  rm -f $PLUGINPATH/_newlogo
  rm -f $PLUGINPATH/_logodata
  rm -f $PLUGINPATH/logos/*
  rm -f $SKINPATH/images/custom/*
  rm -f $PLUGINPATH/logos
  rm -f $SKINPATH/files_custom.conf
fi

if [ -f "$PLUGINPATH/upgrade" ]; then

  wget -q -O $PLUGINPATH/upgradeskin $SOURCEPATH/upgrade_$SKINDIRNAME.sh

  if [ ! -f "$PLUGINPATH/upgradeskin" ]; then
    MESSAGE="Cannot upgrade the skin because a temporary server error. Please try again later or contact support.";
    doMessage
    exit;
  fi
  if [ `ls -lah -1|du $PLUGINPATH/upgradeskin |awk '{print $1}'` -lt 1 ]; then
    MESSAGE="Cannot upgrade the skin because a temporary server error. Please try again later or contact support";
    doMessage
    exit;
  fi
  
  if [ ! -f "/bin/sh" ]; then
    /bin/sh $PLUGINPATH/upgradeskin
  else
    sh $PLUGINPATH/upgradeskin
  fi
  
  rm -f $PLUGINPATH/upgradeskin

fi

if [ -f "$PLUGINPATH/changeimagelogo" ] && [ -f "$PLUGINPATH/imagelogo" ]; then
    mv $SKINPATH/images/logo.gif $SKINPATH/images/logo.gif.bak
    cp $PLUGINPATH/imagelogo $SKINPATH/images/logo.gif
    chown diradmin:diradmin $SKINPATH/images/logo.gif
    rm -f $PLUGINPATH/changeimagelogo
    MESSAGE="The image logo has been updated. Try to refresh your browser if you dont see the change.";
    doMessage
    exit;
fi

if [ -f "$PLUGINPATH/restoreimagelogo" ]; then
    mv $SKINPATH/images/logo.bak $SKINPATH/images/logo.gif
    rm -f $PLUGINPATH/imagelogo
    rm -f $PLUGINPATH/restoreimagelogo
    MESSAGE="The image logo has been restored. Try to refresh your browser if you dont see the change.";
    doMessage
    exit;
fi

exit 0;
